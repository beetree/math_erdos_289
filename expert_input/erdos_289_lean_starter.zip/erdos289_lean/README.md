# Erdős Problem 289: Lean formalization starter

**Status: started, uncompiled, and incomplete.** No Lean compiler was installed
in the authoring environment, and attempts to download Lean and mathlib from
GitHub were denied with HTTP 403. No kernel-checking claim is made for these
source files. They contain explicit elementary proof scripts and no `sorry`,
`admit`, or custom `axiom` declarations; that fact alone does not establish that
they compile or that the candidate theorem is true.

The full Erdős 289 theorem is **not proved in this project**. In particular,
`CandidateStatement` is a proposition definition, not a theorem with an assumed
proof. Importing `OpenObligations` does not assert its propositions.

## What is here

| File | Contents | Current status |
| --- | --- | --- |
| `Erdos289/Intervals.lean` | Exact nonadjacent target; pair/triple masses, separation, disjointness, positive denominators, and target comparison | Proof scripts drafted; uncompiled |
| `Erdos289/Cancellation.lean` | Rational pair identity, explicit common-denominator calculation, and full-factor cancellation | Proof scripts drafted; uncompiled |
| `Erdos289/PowerSmooth.lean` | Prime-power smoothness, inheritance by divisors, largest-factor uniqueness, and a multiplication counterexample | Proof scripts drafted; uncompiled |
| `Erdos289/Padding.lean` | Choose an exact-size padding subset; stage counts, costs, final count, and positivity | Proof scripts drafted; uncompiled |
| `Erdos289/OpenObligations.lean` | Precise propositions for separated fibers, sparse inverse coverage, and dense unit-fraction completion | Stated only; no proofs or assumptions |
| `docs/formalization_plan.md` | Dependency map, source/library inventory, and remaining mathematical work | Research plan |
| `scripts/verify.py` | Source scan, Lean build, then per-theorem axiom dependency checks | Python control flow checked; Lean phases blocked here |

The target explicitly requires `b_i + 1 < a_j` for ordered intervals. It also
requires positive denominators and the linear bound `20*k`. See
[`docs/target.md`](docs/target.md) for the statement audit.

## First reproducible build

The intended versions are **Lean 4.19.0** and **mathlib v4.19.0**, specified in
`lean-toolchain` and `lakefile.toml`. The tagged dependencies could not be fetched
or inspected in this environment. The first real build must check API
compatibility and may require proof-script fixes.

On a machine with [Lean/Elan installed](https://leanprover-community.github.io/install/project.html),
extract this folder, open a terminal in it, and run:

```sh
git init
python3 scripts/verify.py
```

The verifier runs `lake update`, `lake exe cache get`, `lake build`, and an axiom
check for each named theorem. Commit the generated `lake-manifest.json` after
the first successful dependency resolution to preserve all transitive revisions.
The included GitHub Actions workflow performs the same check when these files
are placed at a repository's root. The workflow has **not been run**; no public
repository has been created or updated.

A missing compiler exits with code 2 and writes a blocked result to
`build-report.json`. An elementary-build pass is reported only if both Lean
elaboration and the axiom audit pass. Allowed theorem dependencies are
`propext`, `Classical.choice`, and `Quot.sound`. Even after that pass, the report
keeps `target_proved: false`: the analytic and assembly proofs are still missing.

For a text-only check, run `python3 scripts/verify.py --static-only`. That option
explicitly reports `static_only_uncompiled`; it is not a proof checker.

## Next mathematical milestones

1. Obtain the first compiler run and fix any elaboration/API errors.
2. Connect the finite common-denominator cancellation to `ZMod q` inverse sums,
   constructing the required quotient witnesses and prime-free denominators.
3. Formalize powersmoothness under least common multiples, then the finite
   descending schedule and its denominator invariant.
4. Formalize the auxiliary-pair reservoir and its exact-count application.
5. Prove the three named analytic obligations through their cited sources,
   together with the necessary asymptotic estimates, then assemble the core and
   main-pair constructions.

The last stages are substantial formalization projects. A conditional wrapper
that merely assumes the whole construction would not constitute a formal proof.

## Manuscript version

This starter follows the revised **nonadjacent** candidate dated 4 September
2026, not the superseded adjacency-allowed draft. The source manuscript is
included in `docs/candidate_proof.md` for traceability; including it does not
certify its mathematics.

Source SHA-256:
`be0638fff45c774b34add25dfec190db0ffa0670c96b53df3a2583ac44ba7f4f`.
