# Static review of the Lean starter

Date: 4 September 2026.

**This is a source review, not Lean kernel verification.** No Lean executable was
available to this review, and the target toolchain could not be downloaded in
the authoring environment. The files must still pass the pinned Lean/mathlib
`v4.19.0` build. Neither this document nor the presence of tactic scripts shows
that elaboration succeeds.

The review covered `Intervals`, `Cancellation`, `PowerSmooth`, `Padding`, and
`OpenObligations`. It checked mathematical statements, likely parsing and API
issues, natural-number subtraction and division, the nonadjacency convention,
and whether missing results were being asserted as axioms.

## Concrete issue found

The initial `Cancellation` draft wrote the cleared integer numerator as

```lean
u * V - ∑ m ∈ S, A m - (q : ℤ) * ∑ m ∈ S, B m
```

The first sum binder absorbs the following subtraction. The required expression
is instead

```lean
u * V - (∑ m ∈ S, A m) - (q : ℤ) * (∑ m ∈ S, B m)
```

This affects the common-denominator statement and its repeated expression in
the proof, as well as the numerator-divisibility statement. For example, with
`q=2`, `v=1`, `D=3`, `u=1`, `V=3`, `S={1}`, `A(1)=3`, and `B(1)=1`, all quotient
witness hypotheses hold. The intended cleared numerator is `-2`; the expression
with the subtraction inside the sum is `2`. The issue was reported to the
integration owner for correction. Explicit parentheses are required before a
successful build can be expected.

## Mathematical assessment of the starter

- The target uses `I.hi + 1 < J.lo`, so it excludes adjacent intervals. Positive
  left endpoints and the two permitted endpoint differences exclude zero
  denominators and empty intervals. `Fin k` supplies exactly `k` indices; the
  injectivity proof script additionally records distinctness. The weaker
  ordered-disjointness condition is separately named and has a regression
  example showing why it does not imply nonadjacency.
- After the sum-parenthesization correction, the common-denominator algebra is
  correct: the numerator is `u*V - sum A - q*sum B`, with the specified integer
  quotient witnesses. The full-factor cancellation lemma divides out `q`, not
  merely an underlying prime. It does **not** establish that `D` is prime-free
  by itself. The final wrapper correctly requires that fact separately. The
  bridge from modular inverse coverage to the residue divisibility hypothesis,
  and the construction of a suitable prime-free common denominator, remain to
  be formalized.
- The padding lemmas are mathematically correct under their explicit
  hypotheses. In particular, `actual.card ≤ s` justifies the natural subtraction
  `s - actual.card`; pool size and disjointness justify exact cardinality. The
  final count has the necessary hypothesis `R + C ≤ k`. The cost lemma combines
  existing upper bounds and does not silently assume a sign for `w`. These are
  finite conditional lemmas, not a construction of the auxiliary reservoirs
  or a proof of the complete scheduled descent.
- `PowerSmooth` bounds prime-power divisors, not only primes, and does not
  incorrectly claim closure under multiplication. The counterexample uses
  the prime power `16`. The finite support definition needs `n > 0` to describe
  *all* divisors; the review clarified this and added
  `mem_primePowerSupport` with that positivity hypothesis. Its new proof script
  is also uncompiled.
- The three declarations in `OpenObligations` are definitions of propositions.
  They assert no analytic theorem. Real exponents, rational reciprocal sums,
  and `ZMod q` inverse sums are appropriate types. Natural division in the
  cutoff `q / 2` expresses the intended integral bound because the divisors
  being bounded are naturals. The missing analytic inputs, auxiliary supply,
  induction, and asymptotic assembly remain substantial work.
- No project declaration using `axiom`, `sorry`, `admit`, or `unsafe` was found
  in the five reviewed files. Text searches alone cannot certify elaborated
  dependencies; the project must still inspect the resulting declarations with
  `#print axioms` after a successful build.

## API and elaboration limits

The current primary documentation confirms the argument shapes used for
[`isPrimePow_nat_iff`](https://leanprover-community.github.io/mathlib4_docs/Mathlib/Algebra/IsPrimePow.html#isPrimePow_nat_iff)
and
[`Finset.exists_subset_card_eq`](https://leanprover-community.github.io/mathlib4_docs/Mathlib/Data/Finset/Card.html#Finset.exists_subset_card_eq).
Attempts to inspect the corresponding `v4.19.0` source URLs failed. Therefore
this review does not certify those APIs against the pinned version. In
particular, rational casts, finite-sum rewriting, tactic behavior, and imported
instances still need compiler feedback. No speculative rewrites were made to
otherwise plausible proof scripts merely to manufacture an appearance of
successful verification.

The next meaningful gate is a successful build and axiom audit. After that,
the modular-residue bridge, LCM-based powersmooth denominator control, and
finite scheduled descent are the next mathematical milestones. Nothing in
this starter yet constitutes a formal proof of the posted candidate.

## Applied correction

The missing parentheses in `Cancellation.lean` were added after this review.
Every affected numerator now explicitly reads
`u * V - (∑ m ∈ S, A m) - (q : ℤ) * (∑ m ∈ S, B m)`.
This resolves the reported source-level grouping issue. The corrected scripts
still require their first Lean elaboration run.
