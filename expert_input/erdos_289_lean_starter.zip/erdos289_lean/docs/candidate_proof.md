# Erdős Problem 289: revised candidate for nonadjacent intervals

**Status, 4 September 2026: revised after external feedback.** The previous draft allowed adjacent intervals and therefore did not prove the maintained formulation of Erdős Problem 289. Its statement that it implied that formulation is withdrawn. The reviewers' favorable checks concern that earlier draft. This revision supplies additional arguments for separation and exact interval counting; those arguments require fresh external review. This is a candidate proof, not a certified or accepted resolution.

**Theorem proposed.** For every sufficiently large integer \(k\), there are integer intervals \([a_i,b_i]\), \(1\le i\le k\), such that
\[
1\le a_i\le b_i\le20k,\qquad b_i-a_i+1\in\{2,3\},
\]
\[
b_i+1<a_{i+1}\quad(1\le i<k),\qquad
\sum_{i=1}^k\sum_{n=a_i}^{b_i}\frac1n=1.
\]
Thus at least one unused integer separates consecutive intervals. This is the non-adjacent target identified in the reviewers' quotations of the [maintained problem](https://www.erdosproblems.com/289) and its [discussion](https://www.erdosproblems.com/forum/thread/289). The earlier adjacency-allowed statement is weaker.

**Dependence on published work.** The proof adapts the absorption argument in Section 4 of Conlon–Fox–He–Mubayi–Pham–Suk–Verstraëte, *A Question of Erdős and Graham on Egyptian Fractions*. Its descending cancellation of denominator prime powers, small reciprocal budget, and terminal reservoir are the starting architecture. Lemma 3 below is a sparse version of that paper's inverse-covering theorem, proved by the same bounded-rank progression and divisor-count method. The additional ingredients here are powersmooth consecutive-pair fibers, separation of those pairs, a fixed number of pairs at each correction stage, and a core completed by extending pairs to triples.

The exact-count repair is elementary: at each prime power \(q\), reserve \(s(q)\) extra pairs having only smaller prime powers in their denominators. If cancellation uses \(c\le s(q)\) pairs, add \(s(q)-c\) of these extra pairs. Processing every prime power in a predetermined range then adds a predetermined total number of intervals. No interval is split.

Throughout, an integer is \(y\)-powersmooth if every prime-power divisor is at most \(y\). Write
\[
w(a)=\frac1a+\frac1{a+1},\qquad e_m(x)=\exp(2\pi i x/m).
\]
The largest prime-power divisor refers to numerical size. All logarithms are natural. All constants are fixed before \(k\) tends to infinity. An interval of integers includes both endpoints unless explicitly written half-open.

## 1. The external theorem inputs

The proof uses these three results, with their hypotheses checked where they are applied.

1. **Short sums of modular inverses.** For every sufficiently small fixed \(c>0\), as the integer modulus \(m\) tends to infinity, uniformly in \(m^c<N<m\) and coefficients \(a\) coprime to \(m\),
   \[
   \left|\sum_{\substack{n\le N\\ (n,m)=1}}e_m(a n^{-1})\right|=o(N).
   \]
   The quantitative bound is \(N(\log\log m)^{O_c(1)}/\sqrt{\log m}\). This is [Bourgain–Garaev, *Kloosterman sums in residue rings*, Theorem 5](https://arxiv.org/pdf/1309.1124).

2. **Structure in bounded subset sums.** Given fixed \(\beta>1\), \(0<\eta<1\), there are constants \(c>0,d_0\) with the following property. If \(A\subseteq[1,n]\), \(|A|=m\), \(n\le m^\beta\), and
   \[
   m^\eta\le s\le cm/\log m,
   \]
   there are \(J\subseteq A\), a proper generalized arithmetic progression \(P\) of rank at most \(d_0\), and \(J'\subseteq J\), such that
   \[
   |J|\ge m-c^{-1}s\log m,\quad J\cup\{0\}\subseteq P,\quad |J'|\le s,
   \]
   and the subset sums of \(J'\) contain a translate of the proper dilate \(csP\). We use [Conlon, Fox, He, Mubayi, Pham, Suk, and Verstraëte, *A Question of Erdős and Graham on Egyptian Fractions*, Theorem 3](https://arxiv.org/pdf/2404.16016v2), derived there from [Conlon–Fox–Pham, *Homogeneous structures in subset sums and non-averaging sets*, Theorem 1.5](https://arxiv.org/pdf/2311.01416). A proper progression has one distinct integer for each point in its defining integer coordinate box. Here dilation expands the coordinate intervals while retaining the generators: for a homogeneous representation \(P=\{\sum_i u_i d_i:\alpha_i\le u_i\le\beta_i,\ u_i\in\mathbb Z\}\), the dilate \(tP\) uses integer coordinates in \([t\alpha_i,t\beta_i]\). Thus its generators, and in rank one its common difference, are unchanged. For noninteger \(t\), this definition depends on the representation; we leave the supplied representation and its dilate fixed below.

3. **Dense sets contain a unit-fraction sum of \(1\).** For any fixed \(0<\zeta<1/2\), every sufficiently large \(N\) and \(A\subseteq[1,N]\) with
   \[
   |A|\ge(1-1/e+\zeta)N
   \]
   admit \(D\subseteq A\) with \(\sum_{d\in D}1/d=1\). This is [Liu–Sawhney, *On further questions regarding unit fractions*, Theorem 1.3](https://arxiv.org/pdf/2404.07113).

We also use the classical estimates
\[
\pi(x)\ll x/\log x,\qquad
\sum_{p\le x}\frac1p=\log\log x+B_1+o(1)
\]
for a constant \(B_1\), and the uniform divisor bound \(\tau(n)=n^{o(1)}\). The Erdős–Turán discrepancy inequality converts the first theorem into equidistribution in intervals.

## 2. Nonadjacent prime-power correction families

**Lemma 1.** Fix \(0<\varepsilon<1\). For every sufficiently large prime power \(q=p^a\), there is
\[
I_q\subseteq[q^\varepsilon,2q^\varepsilon]\cap\mathbb Z,
\qquad |I_q|\ge q^{\varepsilon-o(1)},
\]
such that, for every \(m\in I_q\),
\[
p\nmid m,\qquad 4\mid qm,\qquad
qm+1\text{ is }(q/2)\text{-powersmooth}.
\]
The estimate is uniform over prime powers \(q\).

**Proof.** Put \(M=q^\varepsilon\). We construct factorizations
\[
qm+1=rt,\qquad 4M\le t\le5M,\qquad
3q/10\le r\le7q/20.
\tag{2.1}
\]
These ensure \(m=(rt-1)/q\in[M,2M]\) for large \(q\), and both \(r,t<q/2\).

For \(q=2^a\), choose odd \(t\) and require its inverse modulo \(q\) to be in the interval for \(r\). The count of such \(t\) is \(M/40+o(M)\). Among them, \(2\mid m\) if and only if the inverse modulo \(2q\) belongs to the same absolute interval; their count is \(M/80+o(M)\). Thus \(M/80+o(M)\) choices have odd \(m\). Here \(4\mid qm\) is automatic for large \(q\).

For odd \(q=p^a\), choose \((t,2p)=1\) and let \(r\) be the inverse of \(t\) modulo \(4q\), again in the interval (2.1). Then \(4\mid m\). The number of such choices is
\[
\frac1{80}\frac{1-1/p}{2}M+o(M)
=\frac1{160}(1-1/p)M+o(M).
\]
Since \(4\mid m\), the additional condition \(p\mid m\) is equivalent to \(rt\equiv1\pmod{4pq}\). It is counted by requiring the inverse of \(t\) modulo \(4pq\) to be in the same absolute interval. Its relative length is \(1/(80p)\), giving \((1-1/p)M/(160p)+o(M)\) choices. Subtracting leaves
\[
\frac1{160}(1-1/p)^2M+o(M)
\ge M/360+o(M).
\tag{2.2}
\]

Here is the uniform discrepancy justification for all these counts. The moduli are \(q,2q\) in the even case and \(4q,4pq\) in the odd case. For a fixed nonzero Fourier frequency \(h\) and modulus \(U_0\), reduce to \(U=U_0/(h,U_0)\). For large \(q\),
\[
q/|h|\le U\le4q^2,
\]
and the underlying prime \(p\) remains in \(U\). Bourgain–Garaev, with a sufficiently small fixed exponent below \(\varepsilon/2\), applies to differences of prefixes of lengths \(4M,5M\). In the odd case, if \(2\mid U\), the restriction \((t,2p)=1\) is precisely the unit condition for \(U\). If \(U\) is odd, subtract the even terms from the sum over \(p\nmid t\). Substituting \(t=2u\) in those terms gives the phase \(e_U(b2^{-1}u^{-1})\) with unit coefficient, so Bourgain–Garaev applies again to the resulting prefixes of lengths \(2M,5M/2\). In the even case the unit condition remains oddness.

Thus every fixed nonzero Fourier sum is \(o(M)\), uniformly in \(q\). Erdős–Turán, taking \(q\to\infty\) before the fixed cutoff tends to infinity, gives absolute discrepancy \(o(M)\), uniformly over tested intervals. This applies also to the interval of shrinking relative length \(1/(80p)\). The densities of eligible \(t\)'s are \(1/2\) and \((1-1/p)/2\), respectively, with \(O(1)\) counting errors. This proves the counts above.

To enforce powersmoothness, put
\[
\eta=\varepsilon/10000,\qquad D=q^{\varepsilon-\eta}.
\]
Remove every \(t\) with a prime factor exceeding \(D\). Their number is at most
\[
5M\sum_{D<\ell\le5M\atop\ell\ {\rm prime}}\frac1\ell
=\left(5\log\frac{\varepsilon}{\varepsilon-\eta}+o(1)\right)M
<M/1000.
\tag{2.3}
\]
For a surviving factorization, suppose \(u=\ell^b>q/2\) divides \(rt\). Since both factors are less than \(q/2\), \(\ell\mid t\); otherwise \(u\mid r\). Hence \(\ell\le D\), and \(\ell\ne p\).

There are \(O(D\log q)\) such prime powers between \(q/2\) and \(2qM\). For each, \(qm\equiv-1\pmod u\) has at most one solution in \([M,2M]\), because \((q,u)=1\) and \(u>q/2>M\). Each such \(m\) arises from at most \(\tau(qm+1)=q^{o(1)}\) factorizations. Deleting them therefore removes
\[
O(D\log q)q^{o(1)}=q^{\varepsilon-\eta+o(1)}=o(M)
\]
choices. A positive constant times \(M\) remain, by (2.2)–(2.3) and the stronger even-case count. Dividing by the divisor bound gives \(q^{\varepsilon-o(1)}\) distinct valid \(m\). \(\square\)

**Lemma 2.** The pairs \([qm,qm+1]\), for \(m\in I_q\), are mutually disjoint and nonadjacent, including when \(q\) varies.

**Proof.** The largest prime-power divisor of \(qm\) is uniquely \(q\), since \(p\nmid m\) and \(m<q\). Equal left endpoints therefore force equal \(q,m\). All distinct left endpoints are multiples of four, so differ by at least four. Each pair consequently has at least two unused integers before the next pair. \(\square\)

## 3. Sparse modular inverse subsets cover all residues

**Lemma 3.** Fix \(0<\varepsilon<1\). For every sufficiently large prime power \(q\), if
\[
I\subseteq[q^\varepsilon,2q^\varepsilon]\cap\mathbb Z,\quad
(i,q)=1\ \ (i\in I),\quad |I|\ge q^{7\varepsilon/8},
\]
then each residue modulo \(q\) is a sum of inverses of at most \(q^{\varepsilon/2}\) distinct members of \(I\).

This is a sparse extension of Conlon–Fox–He–Mubayi–Pham–Suk–Verstraëte, Theorem 2. The proof follows their progression and divisor-count argument, with the density loss accounted for explicitly.

**Proof.** Put \(s=\lfloor q^{\varepsilon/2}\rfloor\), \(m=|I|\), and represent the inverses by integers in \([1,q-1]\). Apply the progression theorem from Section 1 with \(\beta=2/\varepsilon\), \(\eta=1/3\), and ambient parameter \(n=q\). For sufficiently large \(q\),
\[
q\le m^{2/\varepsilon},\qquad
m^{1/3}\le s\le cm/\log m.
\]
We obtain \(J,P,J'\) with \(|J|\ge m/2\). Keep the representation defining the theorem's dilate fixed:
\[
P=\left\{\sum_{i=1}^{D}n_i d_i:
\alpha_i\le n_i\le\beta_i,\ n_i\in\mathbb Z\right\},
\qquad D\le d_0.
\]
Choose an integer coordinate vector \(v\) representing \(0\in P\). Put \(\ell_i=\lceil\alpha_i\rceil\), \(u_i=\lfloor\beta_i\rfloor\). Call a coordinate active when \(u_i>\ell_i\); all others are constant on \(P\). Relabel the active coordinates \(1,\ldots,d\), and put
\[
a_i=u_i-\ell_i\ge1,\qquad V=\prod_{i=1}^d a_i.
\]
Every \(j\in J\) satisfies
\[
j=\sum_{i=1}^{d}(n_i-v_i)d_i,
\qquad |n_i-v_i|\le a_i,
\]
since the contributions of the constant coordinates vanish after subtracting the representation of zero. There is at least one active coordinate, because \(P\) contains zero and the nonzero elements of \(J\).

The supplied proper GAP \(csP\) is nonempty. Fix each inactive coordinate to any admissible integer in its original dilated interval. This produces a face of that same proper GAP; no representation is changed and no new dilation is formed. For an active coordinate its original dilated interval contains at least
\[
cs(\beta_i-\alpha_i)-1\ge cs a_i-1\ge(cs/2)a_i
\]
integers for large \(q\). Thus the face has at least \((cs/2)^d V\) points. Its supplied translate lies in the subset sums of \(J'\), which lie in \([0,sq]\). Consequently
\[
(cs/2)^d V\le sq+1,\qquad
V\ll_\varepsilon q s^{1-d}
\ll_\varepsilon q^{1-(d-1)\varepsilon/2}.
\tag{3.1}
\]
If \(V\ge q\), this already forces \(d=1\), and the final paragraph below applies. Assume \(V<q\).

We first prove a simultaneous approximation with all rounding included. Set
\[
B_i=\frac{4q}{a_i}(V/q)^{1/d}.
\]
There are \(1\le T<q\) and integers \(e_i\equiv Td_i\pmod q\) with \(|e_i|\le B_i\). Indeed, consider the \(q\) vectors \((t d_i\bmod q)_i\) in \([0,q)^d\). Ignore coordinates with \(B_i\ge q\), and partition each remaining coordinate into intervals of length \(B_i\).

If \(r\ge1\) coordinates remain, the number of boxes is at most
\[
\prod_{i:B_i<q}\frac{2q}{B_i}
\le 2^r\frac{q}{4^d}4^{d-r}
=q/2^r<q.
\]
Here \(\prod_i(q/B_i)=q/4^d\), and \(B_i\le4q\) for ignored coordinates because \(V<q\) and \(a_i\ge1\). If no coordinates remain, there is one box. Two vectors share a box; their nonzero difference, with positive sign, gives the required \(T\). Ignored coordinates impose no restriction. No coprimality assumption on the generators \(d_i\) is needed.

For each \(j\in J\), the centered representative \(h\) of \(Tj\bmod q\) satisfies
\[
|h|\le \min\{q/2,R\},\qquad
R=\sum_i a_iB_i=4dq(V/q)^{1/d}.
\]
Pair this \(h\) with the corresponding \(i\in I\), so that \(j\equiv i^{-1}\pmod q\). There are at least \(|J|\) distinct ordered pairs \((i,h)\), even if multiplication by \(T\) is noninjective. They satisfy
\[
ih=qz+T,\qquad
|z|\le1+8dq^\varepsilon(V/q)^{1/d}.
\]
The product is nonzero because \(1\le T<q\), and \(|ih|\le q^{1+\varepsilon}\). For each \(z\), the divisor bound supplies at most \(q^{o(1)}\) possible ordered pairs. Therefore
\[
\frac m2\le |J|
\le q^{o(1)}\left(1+q^\varepsilon(V/q)^{1/d}\right).
\]
Since \(m\ge q^{7\varepsilon/8}\), the additive \(1\) is absorbed for large \(q\), giving
\[
V\ge q^{1-d\varepsilon/8-o(1)}.
\tag{3.2}
\]
For \(d\ge2\), this contradicts (3.1), because
\[
\frac{(d-1)\varepsilon}{2}-\frac{d\varepsilon}{8}
=\frac{(3d-4)\varepsilon}{8}>0.
\]
The rank is bounded independently of \(q\), so these comparisons are uniform. Thus \(d=1\).

The coordinate-difference representation above shows that every \(j\in J\) is a multiple of \(d_1\). Since these \(j\) are units modulo \(q\), \((d_1,q)=1\). The translated one-dimensional face of the original dilate contained in the subset sums of \(J'\) has at least a constant times \(sV\) terms. If \(V\ge q\), this exceeds \(q\); otherwise (3.2) gives
\[
sV\ge q^{1+3\varepsilon/8-o(1)}>q.
\]
A progression with a unit common difference and at least \(q\) terms covers every residue modulo \(q\). Every such term is a subset sum of \(J'\), which has at most \(s\) members. This proves the lemma. \(\square\)

## 4. A predetermined number of pairs at every correction stage

Fix \(\varepsilon=1/10\). We first give the elementary counting estimate used for both auxiliary and main pairs.

**Lemma 4 (powersmooth supply).** Suppose \(x\to\infty\), \(y=x^{\theta+o(1)}\), and \(0<\theta<1\) is fixed. For fixed \(0<a<b\), the number of integers in \([ax,bx]\) that are not \(y\)-powersmooth is at most
\[
\bigl((b-a)\log(1/\theta)+o(1)\bigr)x.
\tag{4.1}
\]

**Proof.** The number divisible by a prime \(p>y\) is at most
\[
(b-a)x\sum_{y<p\le bx}\frac1p+O(\pi(bx))
=\bigl((b-a)\log(1/\theta)+o(1)\bigr)x
\]
by Mertens' estimate and \(\pi(bx)=o(x)\). For each prime \(p\le y\), let \(u_p\) be its smallest power exceeding \(y\). The number of integers at most \(bx\) divisible by any such \(u_p\) is at most
\[
\sum_{p\le y}\left\lfloor\frac{bx}{u_p}\right\rfloor
\le bx\frac{\pi(y)}{y}=o(x).
\]
Every integer failing powersmoothness is counted in one of these two bounds. \(\square\)

Fix a sufficiently large integer cutoff \(L\). It will later be enlarged to meet the mass requirement. For every prime power \(q>L\), fix a fiber from Lemma 1. Define the larger set of possible correction endpoints
\[
\mathcal P^*=
\bigcup_{\substack{q>L\\q\ {\rm prime\ power}}}
\ \bigcup_{q^{1/10}\le m\le2q^{1/10}\atop m\in\mathbb Z}
\{qm,qm+1\}.
\]
If an endpoint is at most \(X\), then \(q\le X^{10/11}\). Since there are \(O(Y/\log Y)\) prime powers up to \(Y\),
\[
|\mathcal P^*\cap[1,X]|
\ll\sum_{q\le X^{10/11}\atop q\ {\rm prime\ power}}q^{1/10}
\ll X/\log X.
\tag{4.2}
\]
This upper bound is independent of which fibers were chosen.

**Lemma 5 (auxiliary pairs).** For every sufficiently large \(L\), one can fix, simultaneously for each prime power \(q>L\), a family \(\mathcal F_q\) of exactly
\[
s(q)=\lfloor q^{1/20}\rfloor
\]
pairs \([a,a+1]\) satisfying
\[
q^{11/10}\le a,\qquad a+1\le2q^{11/10},\qquad 4\mid a,
\]
with both endpoints \((q/2)\)-powersmooth. All these auxiliary pairs are mutually disjoint and nonadjacent, and are separated from every actual correction pair in Lemma 2. If \(\mathcal F^*\) is their combined endpoint set, then
\[
|\mathcal F^*\cap[1,X]|=O(X^{21/22}).
\tag{4.3}
\]

**Proof.** Construct the families in increasing order of the numerical prime power \(q\). Put \(x=q^{11/10}\), \(y=q/2\), so \(\theta=10/11\) in Lemma 4. Pairs with starts divisible by four and contained in \([x,2x]\) number \(x/4+O(1)\). These candidate pairs are disjoint and nonadjacent. Each bad integer spoils at most one pair; hence at least
\[
\left(\frac14-\log\frac{11}{10}+o(1)\right)x
\tag{4.4}
\]
candidates have both endpoints \(y\)-powersmooth. The constant is positive.

Delete any candidate having an endpoint within distance one of \(\mathcal P^*\). By (4.2), this deletes only \(O(x/\log x)=o(x)\) candidates. Delete also any candidate having an endpoint within distance one of a previously reserved auxiliary endpoint. The number deleted in this second step is at most a constant times
\[
\sum_{q'<q\atop q'\ {\rm prime\ power}}s(q')
\le q^{21/20}=o(q^{11/10})=o(x).
\]
Thus a positive constant times \(x\) candidates remain, more than \(s(q)\), for all sufficiently large \(q\). Select any \(s(q)\) of them. All estimates are uniform, so increasing \(L\) once suffices for the entire ascending construction.

For (4.3), any auxiliary endpoint at most \(X\) has label \(q\le X^{10/11}\). Consequently
\[
|\mathcal F^*\cap[1,X]|
\le2\sum_{q\le X^{10/11}\atop q\ {\rm prime\ power}}q^{1/20}
=O(X^{21/22}).
\]
The families are fixed independently of the later prescribed \(k\) and deficit. \(\square\)

Put \(\mathcal U=\mathcal P^*\cup\mathcal F^*\). Equations (4.2)–(4.3) give
\[
|\mathcal U\cap[1,X]|=O(X/\log X).
\tag{4.5}
\]

We now describe the correction procedure. Given an initial rational deficit with denominator prime powers at most an integer \(H>L\), visit **every numerical prime power** \(q\in(L,H]\) in decreasing order. The invariant before stage \(q\) is that no prime power larger than \(q\) occurs in the current reduced denominator.

If \(q=p^a\) is the full power of \(p\) in that denominator, write the current deficit as \(u/(qv)\), with \(p\nmid uv\). Lemma 3 selects \(S\subseteq I_q\), with \(c_q=|S|\le s(q)\), such that
\[
\sum_{m\in S}m^{-1}\equiv uv^{-1}\pmod q.
\]
Subtract the corresponding pair masses. In rationals whose denominators are coprime to \(p\),
\[
q\,w(qm)=\frac1m+\frac q{qm+1}
\equiv m^{-1}\pmod q.
\tag{4.6}
\]
For an explicit cancellation calculation, let \(D\) be the least common multiple of \(v\) and all the integers \(m,qm+1\) appearing here. Then \(p\nmid D\), and
\[
qD\left(\frac{u}{qv}-\sum_{m\in S}w(qm)\right)
=\frac{uD}{v}-\sum_{m\in S}\frac Dm
-q\sum_{m\in S}\frac D{qm+1}
\]
is an integer divisible by \(q\), by the chosen congruence. The corrected deficit therefore has the form \(z/D\) with \(z\in\mathbb Z\), so its reduced denominator is coprime to \(p\). This eliminates the full factor \(p^a\). Every newly introduced prime power is smaller than \(q\), because \(m<q\) and \(qm+1\) is \((q/2)\)-powersmooth. If the current denominator has no prime-power factor numerically equal to \(q\), set \(S=\varnothing\) and \(c_q=0\).

In either case, now subtract the masses of any \(s(q)-c_q\) pairs from \(\mathcal F_q\). Their denominators introduce only prime powers at most \(q/2\). They can reintroduce a smaller power of the same prime \(p\), which will be handled at its later turn. After the complete stage, every denominator prime power is strictly smaller than \(q\). The descending invariant follows, including at stages requiring only auxiliary pairs.

Each stage adds **exactly \(s(q)\) intervals**. Every selected pair begins at least at \(q^{11/10}\), so its total reciprocal cost is at most
\[
2s(q)q^{-11/10}\le2q^{-21/20}.
\tag{4.7}
\]
The whole correction has predetermined interval count
\[
C_H=\sum_{L<q\le H\atop q\ {\rm prime\ power}}s(q)
\le H^{21/20},
\tag{4.8}
\]
endpoints at most \(2H^{11/10}+1\), and total mass at most
\[
2\sum_{n>L}n^{-21/20}
\le40L^{-1/20}.
\tag{4.9}
\]
All selected pairs are disjoint and nonadjacent by Lemmas 2 and 5. On completion, the reduced denominator has only prime powers at most \(L\). The future choice of the initial deficit will ensure positivity throughout.

## 5. Complete the residual mass without changing the core count

**Lemma 6.** If \(T\to\infty\) through positive integers and \(E_T\subseteq[T,4T)\cap\mathbb Z\) has size \(o(T)\), then \([T,4T)\setminus E_T\) has a subset whose reciprocals sum to \(1\).

**Proof.** Its density in \([1,4T]\) tends to \(3/4>1-1/e+1/20\). Apply Liu–Sawhney with \(\zeta=1/20\). \(\square\)

Fix \(\delta=1/1000\). Choose an integer \(L\) sufficiently large that Lemmas 1–5 apply beyond it and
\[
40L^{-1/20}<\delta/16.
\]
Put
\[
K=\operatorname{lcm}(1,\ldots,L),\qquad
j_0=\lceil K\delta\rceil,\qquad B=4^{j_0},
\tag{5.1}
\]
and enlarge \(L\) if necessary so that \(K\delta\ge2\) and \(K\ge8\). Fix the auxiliary families for this cutoff. All these choices are independent of \(k\).

For \(k\to\infty\), define
\[
Q=\lfloor k^{4/5}\rfloor,\qquad H=KBQ+2,
\]
and reserve parameters
\[
\mathcal R=\{d\in[Q,BQ)\cap\mathbb Z:
[Kd-1,Kd+3]\cap\mathcal U=\varnothing\},
\qquad R=|\mathcal R|.
\tag{5.2}
\]
The protected interval contains the one-integer neighborhood of the possible core triple \([Kd,Kd+2]\). Thus neither that triple nor its shorter pair can overlap or be adjacent to any selected correction or auxiliary pair.

By (4.5), only \(O_{K,B}(Q/\log Q)=o(Q)\) parameters are excluded. In particular,
\[
R=O(Q)=o(k),\qquad C_H=O(k^{21/25})=o(k).
\tag{5.3}
\]
Include the core pair \([Kd+1,Kd+2]\) for every \(d\in\mathcal R\). Distinct possible core triples are separated, since their starts differ by at least \(K\ge8\). The mandatory core mass satisfies
\[
W_{\rm core}\le\frac2K\sum_{Q\le d<BQ}\frac1d
=\frac{2j_0\log4}{K}+o(1)
\le4\delta\log4+o(1)<\frac18.
\tag{5.4}
\]
Here \(j_0/K\le\delta+1/K\le2\delta\).

Every later residual \(j/K\), with \(1\le j\le j_0\), can be supplied by extending selected core pairs to triples. Apply Lemma 6 in the \(j\) disjoint bands
\[
[4^iQ,4^{i+1}Q),\qquad 0\le i<j.
\]
All lie inside \([Q,BQ)\). Each loses \(o(Q)=o(4^iQ)\) available parameters, and there are at most the fixed number \(j_0\) of bands. Obtain disjoint \(D_i\subseteq\mathcal R\) with \(\sum_{d\in D_i}1/d=1\). For every \(d\) in their union add the endpoint \(Kd\) to its core pair. This adds exactly \(j/K\) in reciprocal mass and preserves both nonadjacency and the number \(R\) of core intervals.

## 6. Choose exactly the required number of main pairs

By Lemma 4, in any fixed interval \([ak,bk]\) at most
\[
\bigl((b-a)\log(5/4)+o(1)\bigr)k
\]
integers are not \(Q\)-powersmooth. Take candidate pairs whose starts are divisible by three. They are mutually disjoint and nonadjacent; a bad integer spoils at most one candidate. Thus such an interval contains at least
\[
\gamma(b-a)k+o(k)\quad\text{entirely powersmooth pairs},
\qquad \gamma=\frac13-\log\frac54>0.
\tag{6.1}
\]
In particular,
\[
10\gamma>1,\qquad16\gamma>1.
\tag{6.2}
\]
Only \(O(1)\) pairs are affected by a fixed boundary.

Set
\[
M=k-R-C_H=k-o(k).
\tag{6.3}
\]
For large \(k\), this is a positive integer. Let \(\mathcal A\) contain all entirely powersmooth grid pairs contained in \([k/1024,k]\). Divide this interval into ten dyadic bands \([t,2t]\). Each band contributes at least \(\gamma t+o(k)\) pairs, each of reciprocal mass at least \(1/t\). Hence
\[
\sum_{A\in\mathcal A}\sum_{n\in A}\frac1n
\ge10\gamma+o(1)>1.
\tag{6.4}
\]
There are fewer than \(k/3\) pairs in \(\mathcal A\), and therefore fewer than \(M\).

The far band \([4k,20k]\) supplies more than \(k\) entirely powersmooth grid pairs, by \(16\gamma>1\). Choose any \(M\) of them. Their total mass is at most \(M/(2k)<1/2\).

Replace distinct far pairs one by one with every pair in \(\mathcal A\). Every replacement increases the total mass, by at most \(2048/k\), and the ending mass exceeds \(1\) by (6.4). The target
\[
\tau_k=1-W_{\rm core}-\delta/2
\]
lies in \((1/2,1)\) for large \(k\). Stop at the last configuration before the mass first exceeds \(\tau_k\). The selected main pairs have total mass
\[
\tau_k-2048/k\le W_{\rm main}\le\tau_k.
\tag{6.5}
\]
Their count is exactly \(M\). They are nonadjacent within each band by their spacing-three grid, and the two bands are separated from one another.

The initial deficit is
\[
r_0=1-W_{\rm core}-W_{\rm main}
\in[\delta/2,\delta/2+2048/k].
\tag{6.6}
\]
All prime powers in its reduced denominator are at most \(H\): main endpoints are \(Q\)-powersmooth and core endpoints are numerically at most \(KBQ+2=H\).

## 7. Finish the sum and verify all interval conditions

Run Section 4 through every prime power \(L<q\le H\). Its total cost is less than \(\delta/16\), so every intermediate deficit remains positive. Exactly \(C_H\) nonadjacent pairs are added. The final residual \(r\) has reduced denominator dividing \(K\), and, for large \(k\),
\[
\delta/4\le r\le\delta.
\]
Thus \(r=j/K\) for an integer \(1\le j\le j_0\). Fill it by the pair-to-triple extensions of Section 5. The final reciprocal sum is exactly \(1\).

For completeness, the separation conditions hold for every type of pair of intervals. Correction pairs are mutually separated by Lemma 2; auxiliary pairs are separated from them and from each other by Lemma 5. The protected neighborhoods in (5.2) separate every core interval, including its possible extension, from all those pairs. Distinct core triples themselves are separated by their spacing \(K\). Main pairs are separated from one another by the grid and the two bands. Finally, all correction and auxiliary endpoints are at most
\[
2H^{11/10}+1=O(k^{22/25})=o(k),
\]
and all core endpoints are \(O(k^{4/5})=o(k)\). For sufficiently large \(k\) all these endpoints lie below \(k/1024-2\), separating them from every main interval.

No step changes the number of core intervals, and no intervals are split or merged. The final count is exactly
\[
M+R+C_H=k.
\]
Every interval has two or three members. Main endpoints are at most \(20k\), and all remaining endpoints are \(o(k)\). Ordering the intervals therefore gives precisely the inequalities in the proposed theorem. This completes the candidate proof. \(\square\)

## 8. What changed and what still needs external review

The earlier claim to solve the maintained problem was incorrect because adjacency was allowed. This revision changes all four relevant parts: Lemma 1 restricts correction starts to multiples of four; auxiliary pairs give a fixed stage count; main pairs use a spacing-three grid; and the core excludes the one-integer neighborhoods needed for nonadjacency. The former quadruple-splitting argument has been removed entirely.

The alternative mass-neutral gadgets suggested by reviewers are plausible repairs as well, but are not used in this construction. Predetermined stage counts avoid the need for any final adjustment gadget or simultaneous smoothness estimates for a larger collection of affine forms.

Lemma 3 now centers only the coordinate expressions for members of \(J\), while keeping the theorem-supplied dilate fixed and taking a face of it. This treats singleton coordinates explicitly and removes the dependence on the internal centered construction in the upstream proof. The estimates (3.1)–(3.2) retain the same exponents.

The source attribution is substantive: the inverse-covering method and descending absorption architecture come from the seven-author Egyptian-fractions paper. The new deductions needing scrutiny here include Lemma 1's separated powersmooth fibers, Lemma 3's sparse-density bookkeeping, and Lemma 5 with the predetermined-count descent. The reviewer feedback supplied before this revision does not certify these new steps. Separate internal audits found no unresolved gap in this revision; they do not replace expert review or formal verification.

**Citation numbering.** In the actual PDF of arXiv:2404.16016v2, dated 17 December 2025 and published as Discrete Analysis 2025:28, the positive-density inverse-covering result is Theorem 2 and the structural result is Theorem 3, both on printed page 7. These are the numbers used here; the review feedback's suggested numbers 5 and 6 do not match that PDF.

No explicit usable threshold for sufficiently large \(k\) is obtained. The constants, including \(K\) and \(B\), are extremely large. Earlier finite examples and computational certificates are historical material, not evidence establishing the new asymptotic theorem. The accompanying archive preserves the prior adjacency-allowed draft, marked as superseded, together with the new component audits.
