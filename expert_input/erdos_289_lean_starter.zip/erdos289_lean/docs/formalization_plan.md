# Erdős 289: formalization plan and dependency audit

**Current status: uncompiled starter project.** No Lean compiler is available in this environment, and the attempted GitHub toolchain downloads were blocked with HTTP 403. None of the new Lean source files should yet be described as kernel-checked. The project targets Lean and mathlib `v4.19.0`; successful compilation against that pin remains the first gate.

Date: 4 September 2026. Mathematical source: the revised nonadjacent candidate in `erdos_289_research_note.md`, Sections 1–7, SHA-256 `be0638fff45c774b34add25dfec190db0ffa0670c96b53df3a2583ac44ba7f4f`. This document is a roadmap, not a verification certificate. A module appearing below is planned unless the project's build report identifies its checked declarations.

## 1. Fix the target before formalizing the construction

The main target is the following proposition, with reciprocal sums in `ℚ`:

\[
\exists k_0\;\forall k\ge k_0\;\exists (a_i,b_i)_{i\in\operatorname{Fin}(k)},
\quad 1\le a_i,\quad b_i\le20k,\quad b_i-a_i+1\in\{2,3\},
\]
\[
a_i\le b_i,\qquad
i<j\Longrightarrow b_i+1<a_j,\qquad
\sum_i\sum_{n\in[a_i,b_i]}(n:\mathbb Q)^{-1}=1.
\]

An unordered family with the symmetric separation condition
`bᵢ + 1 < aⱼ ∨ bⱼ + 1 < aᵢ` for distinct indices is an equally suitable primary definition; prove an ordering lemma separately if needed. State positivity explicitly because Lean's inverse at zero is zero. Include `aᵢ ≤ bᵢ` rather than relying on truncated natural subtraction to encode interval length.

The [FormalConjectures file inspected on this date](https://github.com/google-deepmind/formal-conjectures/blob/main/FormalConjectures/ErdosProblems/289.lean) uses `Fin k → ℕ × ℕ`, rational finite interval sums, and only the separation condition `bᵢ < aⱼ ∨ bⱼ < aᵢ`. It also does not explicitly require positive left endpoints. Therefore its displayed predicate is weaker than this project's target. Keep a separately named legacy predicate and prove that the strengthened target implies it. Do not use the existing file as the definition of nonadjacency or import its placeholder as a theorem. Record an immutable repository revision when adding an actual compatibility module; the link above tracks a moving branch.

Regression checks should verify that `[4,5]` and `[6,7]` are disjoint but fail nonadjacency, whereas `[4,5]` and `[7,8]` are separated. These are checks of the statement convention that previously failed, not evidence for the asymptotic theorem.

## 2. Existing mathlib infrastructure

These are locations and declaration names confirmed in current primary documentation. The implementation must check them against the pinned mathlib revision; documentation for a moving version is not a substitute for compilation. Direct attempts to inspect the `v4.19.0` source paths were blocked by the browsing service, so the table is a discovery guide, not a declaration-by-declaration audit of that tag.

| Subject | Existing infrastructure | Use and limitation |
|---|---|---|
| Prime powers | [`Mathlib.Algebra.IsPrimePow`](https://leanprover-community.github.io/mathlib4_docs/Mathlib/Algebra/IsPrimePow.html): `IsPrimePow`, `isPrimePow_nat_iff`, `IsPrimePow.pos`, `IsPrimePow.two_le` | Use the existing predicate for numerical prime powers, including the decidable instance over naturals. Descend by numerical value, not by a separate lexicographic order on base and exponent. |
| Smooth numbers | [`Mathlib.NumberTheory.SmoothNumbers`](https://leanprover-community.github.io/mathlib4_docs/Mathlib/NumberTheory/SmoothNumbers.html): `Nat.smoothNumbers`, `Nat.smoothNumbersUpTo` | These bound prime factors, with a strict bound. They do **not** bound prime powers. For example, arbitrarily large powers of 2 satisfy ordinary 3-smoothness. Introduce a separate powersmooth predicate and prove the required bridges. |
| Modular inverses | [`Mathlib.Data.ZMod.Basic`](https://leanprover-community.github.io/mathlib4_docs/Mathlib/Data/ZMod/Basic.html): `ZMod.unitOfCoprime`, `ZMod.isUnit_iff_coprime`, `ZMod.mul_inv_of_unit`, `ZMod.natCast_eq_zero_iff` | Use `ZMod q` for the residue identity and explicit coprimality hypotheses for inverses. A prime-power modulus is generally not a field. |
| Reduced rational denominators | [`Mathlib.Data.Rat.Lemmas`](https://leanprover-community.github.io/mathlib4_docs/Mathlib/Data/Rat/Lemmas.html): `Rat.add_den_dvd_lcm`, `Rat.sub_den_dvd_lcm`, `Rat.den_dvd` | Finite induction gives denominator control for sums. Using an LCM is crucial: bounding denominators by a product alone does not preserve a prime-power bound. |
| Valuations | [`Mathlib.NumberTheory.Padics.PadicVal.Basic`](https://leanprover-community.github.io/mathlib4_docs/Mathlib/NumberTheory/Padics/PadicVal/Basic.html): `padicValNat.mul`, `padicValNat.prime_pow`, `padicValNat_dvd_iff_le` | An alternative API for the full power of a prime in a denominator. The explicit common-denominator cancellation in manuscript Section 4 may be simpler than introducing localizations. |
| Integer intervals | [`Mathlib.Order.Interval.Finset.Nat`](https://leanprover-community.github.io/mathlib4_docs/Mathlib/Order/Interval/Finset/Nat.html) | Use `Finset.Icc` and `Finset.Ico`, their cardinalities and membership lemmas. Keep half-open reservoir bands distinct from closed blocks. |
| Harmonic bounds | [`Mathlib.NumberTheory.Harmonic.Bounds`](https://leanprover-community.github.io/mathlib4_docs/Mathlib/NumberTheory/Harmonic/Bounds.html): `harmonic_eq_sum_Icc`, `log_add_one_le_harmonic`, `harmonic_le_one_add_log` | Supports reciprocal-mass bounds. The precise fixed-ratio tail estimate still needs a derived lemma. |
| Asymptotics | [`Mathlib.Analysis.Asymptotics.Defs`](https://leanprover-community.github.io/mathlib4_docs/Mathlib/Analysis/Asymptotics/Defs.html) and [`Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics`](https://leanprover-community.github.io/mathlib4_docs/Mathlib/Analysis/SpecialFunctions/Pow/Asymptotics.html) | `IsBigO`, `IsLittleO`, `Tendsto`, and real-power comparison machinery support scale estimates. State the ambient filter and uniform parameters explicitly. |
| Prime counting | [`Mathlib.NumberTheory.PrimeCounting`](https://leanprover-community.github.io/mathlib4_docs/Mathlib/NumberTheory/PrimeCounting.html): `Nat.primeCounting`, `Nat.primesLE` | Supplies counting definitions and basic estimates. Do not infer the manuscript's Mertens asymptotic merely from the presence of this module. |
| Prime reciprocal series | [`Mathlib.NumberTheory.SumPrimeReciprocals`](https://leanprover-community.github.io/mathlib4_docs/Mathlib/NumberTheory/SumPrimeReciprocals.html) | The inspected module proves divergence and summability criteria. These do not by themselves give the asymptotic constant for primes between two power scales used in Lemmas 1 and 4. |

## 3. Recommended elementary definitions and invariants

Use natural thresholds for the algebraic layers, for example

\[
\operatorname{PowerSmooth}(B,n):\Longleftrightarrow
0<n\ \land\ \forall q,\ \operatorname{IsPrimePow}(q)\land q\mid n\Longrightarrow q\le B.
\]

For the bound “at most \(q/2\),” `PowerSmooth (q / 2) n` uses natural division and is equivalent to the intended integer bound. Also use a strict-bound version or `PowerSmooth (q - 1) n` for a completed stage. Prove:

1. Monotonicity in the threshold and closure under positive divisors.
2. Closure under LCM, hence under the reduced denominators of finite rational sums and differences.
3. For positive `n`, equivalence of `PowerSmooth L n` with `n ∣ lcm(1,…,L)`.
4. If `q = p^a`, `p` is prime, `a > 0`, `p ∤ m`, and `0 < m < q`, then `q` is the unique largest prime-power divisor of `q*m`. This provides injectivity of the labels of correction starts.

Use `(a : ℚ)⁻¹ + ((a+1 : ℕ) : ℚ)⁻¹` for pair mass. First prove its two-point interval-sum formula, positivity under `a > 0`, an upper bound from a lower bound on `a`, and the pair-to-triple extension identity. A family of finite starts should be a `Finset ℕ`; use injectivity/separation proofs to turn cardinality of starts into cardinality of blocks.

The most valuable finite interface for inverse coverage is:

\[
\operatorname{CoversInverses}(q,I,s):\Longleftrightarrow
\forall r\in\mathbb Z/q\mathbb Z\ \exists S\subseteq I,
\quad |S|\le s,\quad\sum_{m\in S}(m:\mathbb Z/q\mathbb Z)^{-1}=r.
\]

This is a definition of a local property, not a theorem asserting that suitable fibers exist. A cancellation theorem can take this property as an explicit hypothesis, then prove the new denominator statement by arithmetic. The theorem that produces this property from the sparse interval hypotheses is a separate, substantial obligation.

## 4. Dependency graph

This graph describes proof dependencies, not present completion status.

```mermaid
flowchart TD
  B["Bourgain–Garaev + discrepancy"] --> F["Separated correction fibers"]
  N["Prime and divisor estimates"] --> F
  G["GAP structure + divisor bound"] --> I["Sparse inverse coverage"]
  N --> A["Powersmooth supply and auxiliary families"]
  F --> D["Finite denominator descent"]
  I --> D
  A --> D
  U["Liu–Sawhney density theorem"] --> R["Protected core completion"]
  A --> R
  N --> M["Main-pair interpolation"]
  D --> T["Full nonadjacent target"]
  R --> T
  M --> T
  E["Finite separation and counting"] --> T
```

The finite denominator descent and final assembly need genuine proofs in addition to the analytic inputs. Merely naming the full construction `ConstructionHypothesis` and then proving it implies the target would not formalize the candidate argument.

## 5. Module boundaries and milestones

Proposed names below can be adapted to the actual project layout.

| Priority | Module or milestone | Mathematical deliverable | Dependencies still to discharge |
|---|---|---|---|
| 1 | `Statement` and `Intervals` | Correct target; nonadjacency; grid separation; rational pair/triple identities; implication to the weaker legacy predicate | Ordinary mathlib infrastructure only |
| 2 | `PowerSmooth` | LCM closure, reduced-denominator closure, terminal denominator dividing `K`, correction-label injectivity | Elementary factorization and rational arithmetic |
| 3 | `Cancellation` | Given a local fiber and its inverse coverage, prove cancellation of the entire current power `p^a`, not just one factor of `p` | No analytic theorem needed for the conditional arithmetic statement |
| 4 | `StageCount` and `Descent` | Choosing exactly `s-c` auxiliary starts; finite descent through every numerical prime power in `(L,H]`; total cardinality `∑ s(q)`; strict decrease of denominator prime powers | Local input families and finite bounds are explicit hypotheses; their construction is proved separately |
| 5 | `Core` and `Assembly` | The extension sum is `j/K`; counts do not change; all cross-family separation conditions; ordered output with endpoint bound | Existence and size bounds for the reservoirs and main families remain separate |
| 6 | `Analytic/Fibers` | Manuscript Lemma 1, including `4 ∣ q*m`, uniform prime-power quantifiers, and the sieve deletions | Bourgain–Garaev, discrepancy, prime reciprocal asymptotics, divisor bound |
| 6 | `Analytic/InverseCovering` | Manuscript Lemma 3, with full GAP representation data and sparse exponents | GAP structure theorem and divisor bound |
| 6 | `Analytic/PowersmoothSupply` and `Auxiliary` | Manuscript Lemmas 4–5 and uniform sparsity of all reserved endpoints | Prime counting/asymptotics and an increasing finite-choice construction |
| 6 | `Analytic/DenseUnitFractions` | Manuscript Lemma 6 and its finitely many band applications | Liu–Sawhney |
| 7 | `Main` | Combine all proved components and discharge the “sufficiently large” parameter choices | All preceding milestones |

For the first implementation, the denominator-stage lemmas should be proved for arbitrary finite input sets satisfying transparent local conditions. This tests the genuinely new predetermined-count mechanism independently of the very large analytic formalization. It does **not** make the final theorem unconditional.

For finite descent, use a list of the prime powers in `(L,H]`, sorted in decreasing order, or induction on a natural cutoff. Process every listed value even when it is absent from the current denominator. The invariant is a bound on every prime-power divisor of the reduced denominator. Auxiliary pairs may reintroduce a smaller power of a previously handled prime; the invariant permits exactly that. Track the residual mass, selected starts, count, and denominator bound together.

## 6. External and analytic obligations

No ready-to-import formalization of the three named advanced inputs was located in the inspected primary mathlib documentation or targeted repository searches. This is a limited search result, not proof that no project anywhere has formalized them. A full dependency-free proof must locate and adapt checked formalizations or formalize their proofs.

- **Bourgain–Garaev:** [Theorem 5](https://arxiv.org/pdf/1309.1124). Required coverage includes general moduli, a sufficiently small fixed positive exponent, a uniform coefficient bound, and prefix differences. The correction-fiber proof additionally needs a fully quantified passage from fixed Fourier cutoffs to uniform absolute discrepancy, including the shrinking test intervals and the parity subtraction for reduced odd moduli. A literature citation is not a Lean proof of this input.
- **Conlon–Fox–Pham structure:** the [seven-author Egyptian-fractions paper](https://arxiv.org/pdf/2404.16016v2), derived from [the homogeneous subset-sum theorem](https://arxiv.org/pdf/2311.01416). Encode the generators, real coordinate bounds, integer box, its injective evaluation map, and the exact supplied dilation. Keep the original dilate fixed when taking a face. The candidate's sparse inverse-covering extension is another proof obligation; importing a positive-density covering statement alone would not establish it.
- **Liu–Sawhney:** [Theorem 1.3](https://arxiv.org/pdf/2404.07113). The main construction only needs a fixed density margin inside `[T,4T)`, so expose that simpler corollary at the core-module boundary. Prove the corollary from the full theorem in a separate source module; do not confuse specifying it with proving it.
- **Classical estimates:** prime-counting upper bounds, the prime reciprocal asymptotic in power-scale windows, the subpolynomial divisor bound, and the summable reciprocal-cost tail all need checked statements with the strength used in the manuscript. Existing definitions, divergence theorems, or ordinary-smoothness lemmas do not replace these estimates.
- **Asymptotic assembly:** explicitly prove floor stability and the scales `Q = ⌊k^(4/5)⌋`, `C_H = O(k^(21/25))`, correction endpoints `O(k^(22/25))`, and the fixed-constant treatment of `K` and `B`. A sequence of separate `∀ᶠ` statements must be intersected so that one final threshold satisfies all requirements.

To keep the first implementation manageable, fixed exponents suffice. For example, the fiber-to-covering interface only needs the eventual lower bound `|I_q| ≥ q^(7/80)`, rather than a general formal notation for `q^(1/10-o(1))`. Such a simplification must be proved from the analytic result, and must remain uniform over all sufficiently large prime powers.

## 7. Verification and reporting rules

The default build should contain only proved elementary results and definitions of future goals. Keep unproved goals in documentation or as explicitly named propositions; do not declare them as global axioms. If a theorem is conditional on a local coverage or supply hypothesis, its name, type, and status report should say so. A proven implication with an unproved analytic hypothesis is not a formal proof of Erdős 289.

Pin Lean and mathlib versions; use a reproducible build command and inspect `#print axioms` for the declarations reported as checked. Reject `sorryAx` and project-specific unproved axioms from the checked milestone. Standard logical axioms used by mathlib should be distinguished from missing mathematical proofs. If the toolchain cannot be run, label the code uncompiled and give the actual reason. Never describe successful parsing, a `sorry`-tolerant build, or checked finite examples as verification of the full candidate theorem.

The next substantial milestone after interval arithmetic is the checked cancellation-plus-fixed-count descent. It directly tests the new argument introduced after the adjacency criticism, and has a much smaller prerequisite chain than formalizing all three advanced analytic papers at once.
