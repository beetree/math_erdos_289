# Exact formal target

The candidate statement is `Erdos289.CandidateStatement` in `Erdos289/Intervals.lean`.
It is a **definition of a proposition**, not a proved theorem.

For all sufficiently large natural numbers k, it asks for a `FamilyWitness k`:

- An indexed family `Fin k → NatInterval`.
- Every lower endpoint is at least 1. This prevents Lean's convention `1 / 0 = 0`
  from silently permitting zero denominators.
- Every interval has two or three integer members.
- For every i<j, `hi_i + 1 < lo_j`, requiring an omitted integer between them.
- Every upper endpoint is at most `20 * k`.
- The rational sum of all interval masses is exactly 1.

The proposed elementary lemmas show that separation implies pairwise disjoint
carriers and that the indexed intervals are distinct. Thus `Fin k` really records
k different intervals, not k labels for fewer intervals.

The general `Problem289Statement` permits all interval lengths at least two and
an arbitrary fixed positive integer coefficient C in the bound C*k. The starter
contains the implication `candidate_implies_problem289`, whose hypothesis is the
entire candidate statement. It does not establish that hypothesis.

The existing FormalConjectures file was deliberately not copied as the target:
its strict endpoint inequality permits adjacency. The regression declaration
`NatInterval.adjacency_allowed_is_strictly_weaker` distinguishes the disjoint
pairs [4,5] and [6,7] from a genuinely separated pair of intervals.

The terminal sum is written in the rationals because all finite reciprocal sums
are rational. Any desired real-valued formulation can later be connected by the
standard injective rational-to-real cast; that bridge is not currently needed.
