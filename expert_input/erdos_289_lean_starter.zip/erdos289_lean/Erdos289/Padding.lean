import Mathlib

/-!
# Finite predetermined-count padding

Source draft, not yet compiler-checked. These are finite combinatorial and
budget lemmas. They do not assert the existence of the powersmooth auxiliary
reservoirs; that remains a separate analytic/combinatorial obligation.
-/

open scoped BigOperators

namespace Erdos289

/-- If actual correction uses at most the stage budget, enough disjoint reserved
objects allow the stage to be filled to exactly that budget. -/
theorem exists_exact_padding {α : Type*} [DecidableEq α]
    (actual pool : Finset α) (s : ℕ)
    (hdis : Disjoint actual pool)
    (hactual : actual.card ≤ s) (hpool : s ≤ pool.card) :
    ∃ pad : Finset α, pad ⊆ pool ∧ Disjoint actual pad ∧
      pad.card = s - actual.card ∧ (actual ∪ pad).card = s := by
  have hneed : s - actual.card ≤ pool.card :=
    le_trans (Nat.sub_le s actual.card) hpool
  obtain ⟨pad, hsub, hcard⟩ := Finset.exists_subset_card_eq hneed
  have hdis' : Disjoint actual pad := hdis.mono_right hsub
  refine ⟨pad, hsub, hdis', hcard, ?_⟩
  rw [Finset.card_union_of_disjoint hdis', hcard]
  omega

/-- A property possessed by all reserved objects survives the padding choice. -/
theorem padding_preserves_property {α : Type*}
    (pool pad : Finset α) (P : α → Prop)
    (hsub : pad ⊆ pool) (hpool : ∀ a ∈ pool, P a) :
    ∀ a ∈ pad, P a := by
  intro a ha
  exact hpool a (hsub ha)

/-- Exact stage sizes sum to a count independent of the actual cancellation
choices. Stages include labels absent from the current denominator. -/
theorem scheduled_count {ι : Type*} (stages : Finset ι) (s c : ι → ℕ)
    (hc : ∀ q ∈ stages, c q ≤ s q) :
    (∑ q ∈ stages, (c q + (s q - c q))) = ∑ q ∈ stages, s q := by
  apply Finset.sum_congr rfl
  intro q hq
  have h := hc q hq
  omega

/-- The algebra behind the final number of intervals, with the necessary
non-truncation bound on natural subtraction stated explicitly. -/
theorem final_interval_count (k R C : ℕ) (h : R + C ≤ k) :
    (k - R - C) + R + C = k := by
  omega

/-- A stage whose two families both have per-pair cost at most `w` retains the
same `s*w` bound after filling the slots; there is no extra factor of two. -/
theorem padded_stage_cost {s c : ℕ} {w actualCost padCost : ℝ}
    (hc : c ≤ s) (ha : actualCost ≤ (c : ℝ) * w)
    (hp : padCost ≤ ((s - c : ℕ) : ℝ) * w) :
    actualCost + padCost ≤ (s : ℝ) * w := by
  have hcast : (c : ℝ) + ((s - c : ℕ) : ℝ) = (s : ℝ) := by
    exact_mod_cast (show c + (s - c) = s by omega)
  calc
    actualCost + padCost ≤ (c : ℝ) * w + ((s - c : ℕ) : ℝ) * w := add_le_add ha hp
    _ = ((c : ℝ) + ((s - c : ℕ) : ℝ)) * w := by ring
    _ = (s : ℝ) * w := by rw [hcast]

/-- A global mass budget guarantees positivity at every partial correction
stage; positivity is a separate hypothesis from modular cancellation. -/
theorem residual_positive {r cost budget : ℚ}
    (hcost : cost ≤ budget) (hbudget : budget < r) : 0 < r - cost := by
  linarith

/-- Integer common-denominator completion adds exactly the missing mass. -/
theorem exact_mass_completion (mass residual : ℚ)
    (h : residual = 1 - mass) : mass + residual = 1 := by
  linarith

end Erdos289
