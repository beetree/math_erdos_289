import Mathlib

/-!
# Prime-power smoothness

Source draft, not yet compiler-checked. These definitions bound every prime-power
factor, rather than only prime factors. Ordinary smoothness is insufficient for
the descending denominator argument.
-/

namespace Erdos289

/-- Every prime-power divisor of `n` is numerically at most `y`. -/
def PowerSmooth (y n : ℕ) : Prop :=
  ∀ r : ℕ, IsPrimePow r → r ∣ n → r ≤ y

/-- Increasing the cutoff preserves powersmoothness. -/
theorem PowerSmooth.mono {y z n : ℕ} (h : PowerSmooth y n) (hyz : y ≤ z) :
    PowerSmooth z n := by
  intro r hr hdiv
  exact le_trans (h r hr hdiv) hyz

/-- A divisor inherits every bound on prime-power divisors. -/
theorem PowerSmooth.of_dvd {y m n : ℕ} (h : PowerSmooth y n) (hmn : m ∣ n) :
    PowerSmooth y m := by
  intro r hr hrm
  exact h r hr (dvd_trans hrm hmn)

/-- Positive integers at most the cutoff are powersmooth. -/
theorem powerSmooth_of_le {y n : ℕ} (hn : 0 < n) (hny : n ≤ y) :
    PowerSmooth y n := by
  intro r _ hrn
  exact le_trans (Nat.le_of_dvd hn hrn) hny

/-- For positive `n`, this finite set records all its prime-power divisors.
At `n = 0` it is only a bounded filter, not the full (infinite) divisor support;
the membership theorem therefore requires positivity explicitly. -/
noncomputable def primePowerSupport (n : ℕ) : Finset ℕ := by
  classical
  exact (Finset.range (n + 1)).filter (fun q => IsPrimePow q ∧ q ∣ n)

@[simp] theorem mem_primePowerSupport {n q : ℕ} (hn : 0 < n) :
    q ∈ primePowerSupport n ↔ IsPrimePow q ∧ q ∣ n := by
  simp only [primePowerSupport, Finset.mem_filter, Finset.mem_range]
  constructor
  · exact And.right
  · intro h
    exact ⟨Nat.lt_succ_of_le (Nat.le_of_dvd hn h.2), h⟩

/-- Specifying a largest prime-power factor does not supply an existence proof. -/
structure LargestPrimePower (q n : ℕ) : Prop where
  primePower : IsPrimePow q
  divides : q ∣ n
  maximal : ∀ r : ℕ, IsPrimePow r → r ∣ n → r ≤ q

theorem LargestPrimePower.unique {q r n : ℕ}
    (hq : LargestPrimePower q n) (hr : LargestPrimePower r n) : q = r := by
  exact le_antisymm (hr.maximal q hq.primePower hq.divides)
    (hq.maximal r hr.primePower hr.divides)

theorem LargestPrimePower.powerSmooth {q n : ℕ} (h : LargestPrimePower q n) :
    PowerSmooth q n := h.maximal

/-- Powersmoothness is not closed under multiplication: both factors satisfy
cutoff four, while their product sixteen does not. This guards a tempting but
invalid replacement for the denominator-prime-power bookkeeping. -/
theorem powersmooth_multiplication_counterexample :
    PowerSmooth 4 4 ∧ ¬ PowerSmooth 4 (4 * 4) := by
  constructor
  · exact powerSmooth_of_le (by norm_num) (by norm_num)
  · intro h
    have h16 : IsPrimePow (16 : ℕ) := by
      apply (isPrimePow_nat_iff 16).2
      exact ⟨2, 4, by norm_num, by norm_num, by norm_num⟩
    have hbad : (16 : ℕ) ≤ 4 := h 16 h16 (by norm_num)
    norm_num at hbad

end Erdos289
