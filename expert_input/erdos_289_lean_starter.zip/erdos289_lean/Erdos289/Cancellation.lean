import Mathlib

/-!
# Elementary denominator cancellation for the Erdős 289 candidate

This module formalizes the rational algebra in Section 4 of the manuscript.
It does not assume the analytic existence lemmas and does not assert the final
Erdős conjecture.  The common-denominator statement uses integer quotient
witnesses, making divisibility prerequisites explicit.

Build status: source draft; not compiler-checked in the authoring environment.
-/

namespace Erdos289

open scoped BigOperators

/-- The reciprocal mass of a pair of consecutive positive integers. -/
def pairMass (a : ℕ) : ℚ := 1 / (a : ℚ) + 1 / ((a : ℚ) + 1)

/-- Multiplying a correction pair's mass by its distinguished factor. -/
theorem q_mul_pairMass (q m : ℕ) (hq : 0 < q) (hm : 0 < m) :
    (q : ℚ) * pairMass (q * m) =
      1 / (m : ℚ) + (q : ℚ) / ((q : ℚ) * (m : ℚ) + 1) := by
  have hq' : (q : ℚ) ≠ 0 := by exact_mod_cast (ne_of_gt hq)
  have hm' : (m : ℚ) ≠ 0 := by exact_mod_cast (ne_of_gt hm)
  have hqm : (q : ℚ) * (m : ℚ) + 1 ≠ 0 := by positivity
  unfold pairMass
  push_cast
  field_simp [hq', hm', hqm] <;> ring

/-- An integer quotient witness gives the corresponding rational identity. -/
theorem rational_quotient_of_mul_eq (a D : ℕ) (z : ℤ) (ha : 0 < a)
    (hz : (a : ℤ) * z = (D : ℤ)) :
    (D : ℚ) / (a : ℚ) = (z : ℚ) := by
  have ha' : (a : ℚ) ≠ 0 := by exact_mod_cast (ne_of_gt ha)
  apply (div_eq_iff ha').2
  have hz' : (a : ℚ) * (z : ℚ) = (D : ℚ) := by exact_mod_cast hz
  simpa [mul_comm] using hz'.symm

/-- Explicit common-denominator identity for one finite correction step.

Here `V`, `A m`, and `B m` witness the integer quotients `D/v`, `D/m`,
and `D/(q*m+1)`, respectively.  Existence of these witnesses is exactly the
relevant common-denominator divisibility assertion.
-/
theorem correction_common_denominator
    (q v D : ℕ) (u V : ℤ) (S : Finset ℕ) (A B : ℕ → ℤ)
    (hq : 0 < q) (hv : 0 < v)
    (hm : ∀ m ∈ S, 0 < m)
    (hV : (v : ℤ) * V = (D : ℤ))
    (hA : ∀ m ∈ S, (m : ℤ) * A m = (D : ℤ))
    (hB : ∀ m ∈ S, ((q * m + 1 : ℕ) : ℤ) * B m = (D : ℤ)) :
    (q : ℚ) * (D : ℚ) *
        ((u : ℚ) / ((q : ℚ) * (v : ℚ)) - ∑ m ∈ S, pairMass (q * m)) =
      ((u * V - (∑ m ∈ S, A m) - (q : ℤ) * (∑ m ∈ S, B m) : ℤ) : ℚ) := by
  have hq' : (q : ℚ) ≠ 0 := by exact_mod_cast (ne_of_gt hq)
  have hv' : (v : ℚ) ≠ 0 := by exact_mod_cast (ne_of_gt hv)
  have hV' := rational_quotient_of_mul_eq v D V hv hV
  have hu : (q : ℚ) * (D : ℚ) * ((u : ℚ) / ((q : ℚ) * (v : ℚ))) =
      (u : ℚ) * (V : ℚ) := by
    rw [← hV']
    field_simp [hq', hv'] <;> ring
  have hp : ∀ m ∈ S,
      (q : ℚ) * (D : ℚ) * pairMass (q * m) =
        (A m : ℚ) + (q : ℚ) * (B m : ℚ) := by
    intro m hmem
    have hA' := rational_quotient_of_mul_eq m D (A m) (hm m hmem) (hA m hmem)
    have hB' := rational_quotient_of_mul_eq (q * m + 1) D (B m)
      (Nat.zero_lt_succ _) (hB m hmem)
    calc
      (q : ℚ) * (D : ℚ) * pairMass (q * m) =
          (D : ℚ) * ((q : ℚ) * pairMass (q * m)) := by ring
      _ = (D : ℚ) * (1 / (m : ℚ) +
          (q : ℚ) / ((q : ℚ) * (m : ℚ) + 1)) := by
        rw [q_mul_pairMass q m hq (hm m hmem)]
      _ = (D : ℚ) / (m : ℚ) +
          (q : ℚ) * ((D : ℚ) / ((q * m + 1 : ℕ) : ℚ)) := by
        push_cast
        ring
      _ = (A m : ℚ) + (q : ℚ) * (B m : ℚ) := by rw [hA', hB']
  calc
    (q : ℚ) * (D : ℚ) *
        ((u : ℚ) / ((q : ℚ) * (v : ℚ)) - ∑ m ∈ S, pairMass (q * m)) =
        (u : ℚ) * (V : ℚ) - ∑ m ∈ S, ((A m : ℚ) + (q : ℚ) * (B m : ℚ)) := by
      rw [mul_sub, hu, Finset.mul_sum]
      congr 1
      exact Finset.sum_congr rfl hp
    _ = ((u * V - (∑ m ∈ S, A m) - (q : ℤ) * (∑ m ∈ S, B m) : ℤ) : ℚ) := by
      push_cast
      rw [Finset.sum_add_distrib, ← Finset.mul_sum]
      ring

/-- If the cleared numerator is divisible by the whole factor `q`, that whole
factor cancels.  The conclusion gives a denominator `D`, without any factor of
`q` left over; this is stronger than cancellation of just its underlying prime.
-/
theorem cancel_full_factor (q D : ℕ) (r : ℚ) (N : ℤ)
    (hq : 0 < q) (hD : 0 < D)
    (hclear : (q : ℚ) * (D : ℚ) * r = (N : ℚ))
    (hdiv : (q : ℤ) ∣ N) :
    ∃ z : ℤ, r = (z : ℚ) / (D : ℚ) := by
  obtain ⟨z, hz⟩ := hdiv
  refine ⟨z, ?_⟩
  have hq' : (q : ℚ) ≠ 0 := by exact_mod_cast (ne_of_gt hq)
  have hD' : (D : ℚ) ≠ 0 := by exact_mod_cast (ne_of_gt hD)
  apply (eq_div_iff hD').2
  have hz' : (N : ℚ) = (q : ℚ) * (z : ℚ) := by exact_mod_cast hz
  have heq : (q : ℚ) * ((D : ℚ) * r) = (q : ℚ) * (z : ℚ) := by
    simpa [mul_assoc, hz'] using hclear
  have hc := mul_left_cancel₀ hq' heq
  simpa [mul_comm] using hc

/-- The inverse-covering congruence, after clearing the invertible denominators,
is exactly the first divisibility hypothesis below.  The second portion of the
pair mass already has a factor `q`, so it does not affect that congruence. -/
theorem correction_numerator_dvd (q : ℕ) (u V : ℤ)
    (S : Finset ℕ) (A B : ℕ → ℤ)
    (hresidue : (q : ℤ) ∣ u * V - (∑ m ∈ S, A m)) :
    (q : ℤ) ∣ u * V - (∑ m ∈ S, A m) - (q : ℤ) * (∑ m ∈ S, B m) := by
  apply dvd_sub hresidue
  exact ⟨∑ m ∈ S, B m, rfl⟩

/-- One algebraic absorption step removes the complete distinguished factor
from an available common denominator.  The analytic covering theorem will
supply `S` and `hresidue`; it is not assumed or formalized in this module. -/
theorem correction_cancels_with_divisible_numerator
    (q v D : ℕ) (u V : ℤ) (S : Finset ℕ) (A B : ℕ → ℤ)
    (hq : 0 < q) (hv : 0 < v) (hD : 0 < D)
    (hm : ∀ m ∈ S, 0 < m)
    (hV : (v : ℤ) * V = (D : ℤ))
    (hA : ∀ m ∈ S, (m : ℤ) * A m = (D : ℤ))
    (hB : ∀ m ∈ S, ((q * m + 1 : ℕ) : ℤ) * B m = (D : ℤ))
    (hresidue : (q : ℤ) ∣ u * V - (∑ m ∈ S, A m)) :
    ∃ z : ℤ,
      (u : ℚ) / ((q : ℚ) * (v : ℚ)) - ∑ m ∈ S, pairMass (q * m) =
        (z : ℚ) / (D : ℚ) := by
  exact cancel_full_factor q D _ _ hq hD
    (correction_common_denominator q v D u V S A B hq hv hm hV hA hB)
    (correction_numerator_dvd q u V S A B hresidue)

/-- A representation whose denominator has no factor `p`.  This definition does
not impose a choice of reduced fraction and needs no primality hypothesis. -/
def HasPrimeFreeDenominator (p : ℕ) (r : ℚ) : Prop :=
  ∃ (z : ℤ) (D : ℕ), 0 < D ∧ ¬ p ∣ D ∧ r = (z : ℚ) / (D : ℚ)

/-- Clearing a numerator divisible by all of `q` preserves a denominator with
no factor `p`, if the chosen remaining common denominator has that property.
In the application `q = p^a`; no exponent-one cancellation is substituted. -/
theorem cancel_full_factor_prime_free (q D p : ℕ) (r : ℚ) (N : ℤ)
    (hq : 0 < q) (hD : 0 < D) (hpD : ¬ p ∣ D)
    (hclear : (q : ℚ) * (D : ℚ) * r = (N : ℚ))
    (hdiv : (q : ℤ) ∣ N) :
    HasPrimeFreeDenominator p r := by
  obtain ⟨z, hz⟩ := cancel_full_factor q D r N hq hD hclear hdiv
  exact ⟨z, D, hD, hpD, hz⟩

end Erdos289
