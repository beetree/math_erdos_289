import Erdos289.PowerSmooth

/-!
# Explicit unproved analytic obligations

The declarations in this module DEFINE propositions. They do not assert them,
are not axioms, and are not proofs of the final conjecture. The starter project
has not established even these inputs or a complete implication from them to
the target. Further asymptotic, reservoir, and assembly work is listed in the
roadmap. Source is uncompiled in the authoring environment.
-/

open scoped BigOperators

namespace Erdos289.OpenObligations

/-- The separated fiber consequence needed from manuscript Lemma 1. The weaker
explicit exponent 7*ε/8 is sufficient to feed the next obligation. -/
def SeparatedFibers : Prop :=
  ∀ ε : ℝ, 0 < ε → ε < 1 →
    ∃ q₀ : ℕ, ∀ q : ℕ, q₀ ≤ q → IsPrimePow q →
      ∃ I : Finset ℕ,
        (q : ℝ) ^ (7 * ε / 8) ≤ (I.card : ℝ) ∧
        ∀ m ∈ I,
          (q : ℝ) ^ ε ≤ (m : ℝ) ∧
          (m : ℝ) ≤ 2 * (q : ℝ) ^ ε ∧
          Nat.Coprime m q ∧ 4 ∣ q * m ∧
          PowerSmooth (q / 2) (q * m + 1)

/-- Manuscript Lemma 3 as an exact finite subset-sum conclusion in `ZMod q`.
No modular covering theorem is assumed by importing this definition. -/
def SparseInverseCovering : Prop :=
  ∀ ε : ℝ, 0 < ε → ε < 1 →
    ∃ q₀ : ℕ, ∀ q : ℕ, q₀ ≤ q → IsPrimePow q →
      ∀ I : Finset ℕ,
        (∀ m ∈ I, (q : ℝ) ^ ε ≤ (m : ℝ) ∧
          (m : ℝ) ≤ 2 * (q : ℝ) ^ ε ∧ Nat.Coprime m q) →
        (q : ℝ) ^ (7 * ε / 8) ≤ (I.card : ℝ) →
        ∀ r : ZMod q, ∃ S : Finset ℕ, S ⊆ I ∧
          (S.card : ℝ) ≤ (q : ℝ) ^ (ε / 2) ∧
          (∑ m ∈ S, (m : ZMod q)⁻¹) = r

/-- The precise dense-set input of Liu–Sawhney used in the protected core.
The rational sum is exact. The density threshold is stated in the reals. -/
def DenseUnitFractions : Prop :=
  ∀ ε : ℝ, 0 < ε → ε < 1 / 2 →
    ∃ N₀ : ℕ, ∀ N : ℕ, N₀ ≤ N →
      ∀ A : Finset ℕ, A ⊆ Finset.Icc 1 N →
        (1 - Real.exp (-1) + ε) * (N : ℝ) ≤ (A.card : ℝ) →
        ∃ D : Finset ℕ, D ⊆ A ∧ (∑ d ∈ D, (1 : ℚ) / (d : ℚ)) = 1

end Erdos289.OpenObligations
