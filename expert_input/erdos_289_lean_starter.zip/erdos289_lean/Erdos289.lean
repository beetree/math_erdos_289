import Erdos289.Intervals
import Erdos289.Cancellation
import Erdos289.PowerSmooth
import Erdos289.Padding
import Erdos289.OpenObligations

/-!
# Erdős 289 formalization starter

This root module exposes statement definitions and elementary proof drafts.
`Erdos289.CandidateStatement` is NOT proved here. The analytic existence
obligations are propositions only; they have no assumed instances.

The source has not yet been compiled in the authoring environment.
-/
