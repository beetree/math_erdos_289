#!/usr/bin/env python3
"""Build and audit the starter; a missing compiler is a failure, never a pass.

The lexical scan is a convenience check. Kernel elaboration and the subsequent
#print axioms audit are separate, mandatory steps for an elementary-build pass.
Even a passed elementary build does not prove CandidateStatement.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / 'build-report.json'
ALLOW_AXIOMS = {'propext', 'Classical.choice', 'Quot.sound'}
FORBIDDEN = {'sorry', 'admit', 'axiom', 'unsafe', 'native_decide'}


def remove_comments_and_strings(source: str) -> str:
    """Preserve newlines while stripping Lean nested comments and strings."""
    out = []
    i = depth = 0
    in_string = False
    while i < len(source):
        if depth:
            if source.startswith('/-', i):
                depth += 1; out.extend('  '); i += 2
            elif source.startswith('-/', i):
                depth -= 1; out.extend('  '); i += 2
            else:
                out.append('\n' if source[i] == '\n' else ' '); i += 1
        elif in_string:
            if source[i] == '\\' and i + 1 < len(source):
                out.extend('  '); i += 2
            elif source[i] == '"':
                in_string = False; out.append(' '); i += 1
            else:
                out.append('\n' if source[i] == '\n' else ' '); i += 1
        elif source.startswith('/-', i):
            depth = 1; out.extend('  '); i += 2
        elif source.startswith('--', i):
            j = source.find('\n', i)
            if j < 0: j = len(source)
            out.extend(' ' * (j - i)); i = j
        elif source[i] == '"':
            in_string = True; out.append(' '); i += 1
        else:
            out.append(source[i]); i += 1
    if depth or in_string:
        raise ValueError('Unclosed Lean comment or string')
    return ''.join(out)


def inspect_sources() -> dict:
    paths = [ROOT / 'Erdos289.lean'] + sorted((ROOT / 'Erdos289').glob('*.lean'))
    inventory = []
    issues = []
    for path in paths:
        source = path.read_text()
        clean = remove_comments_and_strings(source)
        tokens = set(re.findall(r'\b[A-Za-z_][A-Za-z_0-9]*\b', clean))
        bad = sorted(tokens & FORBIDDEN)
        if bad: issues.append(f'{path.name}: forbidden proof escape(s): {bad}')
        if re.search(r'set_option\s+debug\.skipKernelTC', clean):
            issues.append(f'{path.name}: kernel checking disabled')
        scopes = []
        theorems = []
        definitions = []
        for line in clean.splitlines():
            line = re.sub(r'^\s*@\[[^\]]*\]\s*', '', line).strip()
            ns = re.match(r'^namespace\s+(\S+)', line)
            if ns:
                scopes.append(('namespace', ns.group(1))); continue
            sec = re.match(r'^section(?:\s+(\S+))?\s*$', line)
            if sec:
                scopes.append(('section', sec.group(1) or '')); continue
            if re.match(r'^end(?:\s+\S+)?\s*$', line):
                if not scopes: issues.append(f'{path.name}: unmatched end')
                else: scopes.pop()
                continue
            decl = re.match(r'^(?:(?:noncomputable|protected|private)\s+)*'
                            r'(theorem|lemma|def|structure)\s+([^\s({:]+)', line)
            if decl:
                prefix = '.'.join(name for kind, name in scopes if kind == 'namespace')
                name = '.'.join(filter(None, [prefix, decl.group(2)]))
                (theorems if decl.group(1) in {'theorem', 'lemma'} else definitions).append(name)
        if scopes: issues.append(f'{path.name}: unclosed namespace/section')
        inventory.append({'path': str(path.relative_to(ROOT)),
                          'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                          'lines': len(source.splitlines()),
                          'theorems': theorems, 'definitions': definitions})
    return {'status': 'passed' if not issues else 'failed',
            'issues': issues, 'files': inventory,
            'theorem_drafts': sum(len(x['theorems']) for x in inventory)}


def run(command: list[str]) -> subprocess.CompletedProcess:
    print('+ ' + ' '.join(command), flush=True)
    result = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    print(result.stdout, end='', flush=True)
    return result


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--static-only', action='store_true',
                    help='Inspect source text only; explicitly does not check Lean.')
    args = ap.parse_args()
    static = inspect_sources()
    report = {'checked_at_utc': datetime.now(timezone.utc).isoformat(),
              'target_proved': False,
              'lean_toolchain': (ROOT / 'lean-toolchain').read_text().strip(),
              'static_checks': static, 'kernel_build': 'not_run',
              'axiom_audit': 'not_run'}
    try:
        if static['issues']:
            report['status'] = 'source_check_failed'; return 1
        if args.static_only:
            report['status'] = 'static_only_uncompiled'; return 0
        if shutil.which('lake') is None:
            report['status'] = 'blocked_missing_toolchain'
            report['blocker'] = ('Lean/Lake is not installed. Authoring environment '
                                 'denied GitHub toolchain and mathlib downloads (HTTP 403).')
            print(report['blocker'], flush=True)
            return 2
        for command in [['lake', 'update'], ['lake', 'exe', 'cache', 'get'],
                        ['lake', 'build']]:
            result = run(command)
            if result.returncode:
                report['status'] = 'build_failed'
                report['failed_command'] = command
                report['output_tail'] = result.stdout[-12000:]
                report['kernel_build'] = 'failed' if command[-1] == 'build' else 'not_run'
                return result.returncode
        report['kernel_build'] = 'passed'
        names = [n for f in static['files'] for n in f['theorems']]
        audit_path = ROOT / '.lake' / 'Erdos289AxiomAudit.lean'
        audit_path.write_text('import Erdos289\n\n' + '\n'.join(
            '#print axioms ' + n for n in names) + '\n')
        result = run(['lake', 'env', 'lean', str(audit_path)])
        if result.returncode:
            report['status'] = 'axiom_audit_failed'
            report['axiom_audit'] = 'failed'
            report['output_tail'] = result.stdout[-12000:]
            return result.returncode
        entries = re.findall(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|"
                             r"does not depend on any axioms)", result.stdout, re.S)
        found = {name: [s.strip() for s in ax.split(',') if s.strip()] for name, ax in entries}
        missing = sorted(set(names) - found.keys())
        forbidden = {name: sorted(set(axioms) - ALLOW_AXIOMS)
                     for name, axioms in found.items() if set(axioms) - ALLOW_AXIOMS}
        report['axiom_dependencies'] = found
        if missing or forbidden:
            report['status'] = 'axiom_audit_failed'
            report['axiom_audit'] = 'failed'
            report['missing_declarations'] = missing
            report['unapproved_axioms'] = forbidden
            return 1
        report['status'] = 'elementary_modules_checked_target_unproved'
        report['axiom_audit'] = 'passed'
        return 0
    finally:
        REPORT.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
        print(json.dumps({k: report[k] for k in ['status', 'target_proved',
                                               'kernel_build', 'axiom_audit']}, indent=2))


if __name__ == '__main__':
    sys.exit(main())
